rm(list=ls())
library(dygraphs)
library(zoo)

X = read.table("PQ_Hupsel_dag_68_05.dat",header=TRUE)
X$date <- apply( X[ ,1:3 ] , 1 , paste , collapse = "-" )
X = data.frame(date=X$date,P=X$P,Q=X$Q/mean(X$Q)*mean(X$P))
Z = zoo(X[,2:3],as.Date(X[,1],format("%Y-%m-%d")))
plot(Z)

save(Z,file="hupsel.Rdat")

dygraph(Z,main="Hupsel")%>% dySeries("Q",drawPoints=TRUE,col="red",strokeWidth=2)%>%
  dySeries("P",stepPlot=TRUE,col="blue",strokeWidth=2)

dygraph(Z,main="Hupsel")%>%  dySeries("P",stepPlot=TRUE,col=rgb(50/255,100/255,200/255),strokeWidth=2)%>%
  dySeries("Q",drawPoints=TRUE,col="red",strokeWidth=2)%>%dyRangeSelector(dateWindow = c("1980-01-01", "1985-01-01"))

